import { StacheElement, ObservableArray } from "//unpkg.com/can@pre/core.mjs";

class VMatch extends StacheElement {
  static view = `
    <div class="header"></div>
    <div class="result {{# if(this.liker) }}liker{{/ if }}
                       {{# if(this.disliker) }}disliker{{/ if }}"></div>
    <div class="images">
      <div class="present" style="left: {{ this.amountMoved }}px">
        <img
          alt="Present Profile Image"
          src="{{ this.presentProfile.img }}"
          draggable="false"
        >
      </div>
      <div class="succeeding">
        <img alt="Succeeding Profile Image" src="{{ this.succeedingProfile.img }}">
      </div>
    </div>

    <div class="footer">
      <button class="exBtn" on:click="this.ex()">Dislike</button>
      <button class="heartBtn" on:click="this.heart()">Like</button>
    </div>
  `;

  static props = {
    profiles: {
      get default() {
        return new ObservableArray([
          { name: "Burlington Food Drive", img: "https://pbs.twimg.com/profile_images/909765924965748737/nUpjSBR8.jpg" },
          { name: "Habitat For Humanity", img: "https://www.cornwallseawaynews.com/wp-content/uploads/sites/19/2019/01/habitat.jpg" },
          { name: "Big Brother/Sisters", img: "http://getconnected.volunteerlubbock.org/content/getconnected.volunteerlubbock.org/agency/3983.jpg?1502835941?area=agency" },
          { name: "Animal Services", img: "http://www.oavt.org/CMImages/Volunteer/BASLOGO.jpg" },
          { name: "Meals On Wheels", img: "https://pbs.twimg.com/profile_images/1318751152/logofb_400x400.jpg" },
          { name: "Regeneration Outreach", img: "https://pbs.twimg.com/profile_images/1318751152/logofb_400x400.jpg" },
          { name: "Sunshine Foundation", img: "https://pbs.twimg.com/profile_images/667442082018127872/WnTrC4Kc.png" },
          { name: "YMCA", img: "https://pbs.twimg.com/profile_images/884568336172023809/lqh-JcCC_400x400.jpg" },
          { name: "Heart & Stroke", img: "https://www.lifesaverfirstaid.ca/wp-content/uploads/2016/12/hs-large-logo-just-heart.png" },
          { name: "Peel Children's Aid", img: "https://ea-user-images.s3.amazonaws.com/uploads/charity/logo/350/medium_thumb_orig.png" }
        ]);
      }
    },

    amountMoved: Number,

    emptyProfile: {
      get default() {
        return {
          img: "http://thissideupfamily.org/wp-content/uploads/2011/03/Volunteer-NOW-button.jpg"
        };
      }
    },

    get presentProfile() {
      return this.profiles[0] || this.emptyProfile;
    },

    get succeedingProfile() {
      return this.profiles[1] || this.emptyProfile;
    },

    get liker() {
      return this.amountMoved >= 100;
    },

    get disliker() {
      return this.amountMoved <= -100;
    }
  };

  heart() {
    console.log("LIKED");
    this.profiles.shift();
  }

  ex() {
    console.log("DISLIKED");
    this.profiles.shift();
  }

  connected() {
    var present = this.querySelector(".present");
    var startingX;

    this.listenTo(present, "pointerdown", event => {
      startingX = event.clientX;

      this.listenTo(document, "pointermove", event => {
        this.amountMoved = event.clientX - startingX;
      });

      this.listenTo(document, "pointerup", event => {
        this.amountMoved = event.clientX - startingX;

        if (this.liker) {
          this.heart();
        } else if (this.disliker) {
          this.ex();
        }

        this.amountMoved = 0;
        this.stopListening(document);
      });
    });
  }
}

customElements.define("v-match", VMatch);