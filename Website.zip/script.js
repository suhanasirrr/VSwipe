$(".read-more").mouseover(function () {

    $("#card-group-description-container").css("border-bottom-left-radius", "50px");
    $("#card-group-description-container").css("border-bottom-right-radius", "50px");

    $(".read-more").css("background-color", "#6395F2");
    $(".read-more").css("color", "white");

});

$(".read-more").mouseout(function () {

    $("#card-group-description-container").css("border-bottom-left-radius", "0");
    $("#card-group-description-container").css("border-bottom-right-radius", "0");

    $(".read-more").css("background-color", "white");
    $(".read-more").css("color", "#6395F2");

});

var volCardList;
var seenArr = [];

$.getJSON("https://api.myjson.com/bins/ikx2f", "", volCardCallback);


function volCardCallback(data) {
    // Initialize volCardList Variable
    volCardList = data;
    createVolCard(volCardList[0]);

}

$('#button-no').click(function() {
    // Increment Index of list
    var x = [Math.floor(Math.random() * volCardList.length)];

    // Check array size
    if (volCardList.length <= 1) {
        $("#button-no").css("display", "none");
    }


    //Push Value of Card
    createVolCard(volCardList[x]);

    // Remove Values
    volCardList.splice(x, 1);

    // Remake Array
    var temp = [];
    for (var i = 0; i < volCardList.length; i++) {
        if (volCardList[i] != undefined) {
            temp.push(volCardList[i]);
        }
    }

    volCardList = temp;

});


function createVolCard(cardData) {

    // Card Varaibles
    var cardTitle, cardCompany, cardImage, cardTags, cardDescription;

    cardTitle = cardData.title;
    cardCompany = cardData.companyName;
    cardImage = cardData.imageLocation;
    cardTags = cardData.oppurtunityTags;
    cardDescription = cardData.description;


    $('#button-no').click(function() {
        $('#card-group-title').text(cardTitle);
    });

    $('#button-no').click(function() {
        $('#card-group-company').text(cardCompany);
    });

    $('#button-no').click(function() {
        $('#card-group-tags').text(cardTags);
    });

    $('#button-no').click(function() {
        $('#card-group-description').text(cardDescription);
    });

    $('#button-no').on({
        'click': function (){
            $("#card-group-img").attr("src", cardImage);
        }
    });

}



function randomizer() {

};